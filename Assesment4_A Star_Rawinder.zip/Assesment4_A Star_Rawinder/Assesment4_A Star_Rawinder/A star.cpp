#include "A Star.h"

// Function to validate whether a node is in range or not
bool  AStar::IsValid(int row, int col)
{
	if (row >= 0 && row < Row)		// Condition checks range
	{
		return (true); // Return true if node is in the specified range
	}
	if (col >= 0 && col < Col);
	{
		return (true);
	}
}

// Function checks whether a node is a Obstical or not
bool AStar::InUnBlocked(int grid[][Col], int row, int col)
{
	if (grid[row][col] == 1)
	{
		return (true);		// Returns true as the node is not an obstical
	}
	else
	{
		return (false);		// Returns false when an obstical
	}
}

// Function to check whether the selected Destination has been reached
bool AStar::IsDestination(int row, int col, Pair dest)
{
	if (row == dest.first && col == dest.second)	// Checks if the row and col match the dest specification
	{
		return (true);		// Return the destination has been reached
	}
	else
	{
		return (false);
	}
}

// Function to calculate the Heuristic (Local and Global goal estimations)
double AStar::CalculateHeuristic(int row, int col, Pair dest)
{
	// Euclidean Distance
	// Distance between the current node and the goal node using the distance formula
	return ((double)sqrt((row - dest.first) * (row - dest.first) + (col - dest.second) * (col - dest.second)));
}

int X, Y;

// Function to get the Path from the source to goal node
void AStar::PathAStar(Node cellDetails[][Col], Pair dest)
{
	printf("\nThe Path is ");
	int row = dest.first;		// Source node dets
	int col = dest.second;

	stack<Pair> Path;			// Stack STL inorder to store the path from our A * algo 

	while (!(cellDetails[row][col].ParentI == row		//While loop condition loop until the parent nodes are the source node
		&& cellDetails[row][col].ParentJ == col))
	{
		Path.push(make_pair(row, col));		// In every interation push the pair into the stack 

		int temp_row = cellDetails[row][col].ParentI;	// Create temp vars
		int temp_col = cellDetails[row][col].ParentJ;
		row = temp_row;		// Set to temp vars created
		col = temp_col;
	}

	Path.push(make_pair(row, col));		// Final push into the stack 
	while (!Path.empty())	// While loop to interate until the stack is empty 
	{
		pair<int, int> p = Path.top();		// Get the top of the stack 
		Path.pop();			// Pop the top pair 
		printf("-> [%d,%d] ", p.first, p.second);		// Print the pair
		X = p.first;
		Y = p.first;

		// This loop will pop out the path from the source to the destination 
	}

	return;
}

// Function implements the A Star Search Algorythm
void AStar::AStarSearch(int grid[Row][Col], Pair source, Pair dest)
{
	int i, j;

	// Prior to the execution of the actual Algo code
	// we need to make sure of this following conditions
	// inorder to prevent a crash in the Algo

	// First we check is the source node is out of the range
	if (IsValid(source.first, source.second) == false)
	{
		cout << "The source is invalid" << endl;
		return;
	}
	if (IsValid(dest.first, dest.second) == false)
	{
		cout << "The distinnation is invalid" << endl;
		return;
	}

	// We then need to check whether the source or destinatation are obsticals or not
	if (InUnBlocked(grid, source.first, source.second) == false)
	{
		cout << "Source is an obstical" << endl;		// Checking Source
		return;
	}
	if (InUnBlocked(grid, dest.first, dest.second) == false)
	{
		cout << "Destination is obstical" << endl;	// Checking Destination
		return;
	}

	// Lastly we check if the destination is the source node
	if (IsDestination(source.first, source.second, dest) == true)
	{
		cout << "We are at the destination already" << endl;
		return;
	}

	// Boolean 2D array (closed list) litilised to false as
	// no cell has been included yet
	bool ClosedList[Row][Col];
	memset(ClosedList, false, sizeof(ClosedList));	// Fill the block of memory 

	// Another 2D array of type Node to hold the details of
	// that Node
	Node NodeDets[Row][Col];

	for (i = 0; i < Row; i++)
	{
		for (j = 0; j < Col; j++)
		{
			// Initilising the Heuristic Vars to defaluts for every Node
			NodeDets[i][j].F = FLT_MAX;
			NodeDets[i][j].G = FLT_MAX;
			NodeDets[i][j].H = FLT_MAX;

			// Initilising the Parents of each Node
			NodeDets[i][j].ParentI = -1;
			NodeDets[i][j].ParentJ = -1;
		}
	}

	// Initialising the vars if the start Node
	i = source.first, j = source.second;
	NodeDets[i][j].F = 0.0;
	NodeDets[i][j].G = 0.0;
	NodeDets[i][j].H = 0.0;
	NodeDets[i][j].ParentI = i;
	NodeDets[i][j].ParentJ = j;

	// Open list implemented using the pair of pair
	// Will include the F value and the Row and Col dets for the Node
	set<pPair> openList;


	// Make the start Node to the Open List
	openList.insert(make_pair(0.0, make_pair(i, j)));

	// Bool which is returning false as the the destination
	bool FoundDest = false;

	while (!openList.empty())
	{
		// SET pair p to List begin
		pPair p = *openList.begin();

		// Remove from the Open list
		openList.erase(openList.begin());

		// Add to the Closed List
		i = p.second.first;
		j = p.second.second;
		ClosedList[i][j] = true;

		// F, G, H of the Current
		double GNew, HNew, FNew;

		// UP Neigbour

		// Check whether this node is valid
		if (IsValid(i - 1, j) == true)
		{
			// Check whether the destination is this Neighbour
			if (IsDestination(i - 1, j, dest) == true)
			{

				NodeDets[i - 1][j].ParentI = i;
				NodeDets[i - 1][j].ParentJ = j;
				cout << "The destination node had been found " << endl;
				PathAStar(NodeDets, dest);
				FoundDest = true;
				return;
			}
			// Ingore the neighbour if on close or an obsitical
			// Else

			else if (ClosedList[i - 1][j] == false && InUnBlocked(grid, i - 1, j) == true) // Meaning the neighbour is explorable
			{
				// Calculation of the Heuristic
				GNew = NodeDets[i][j].G + 1.0;
				HNew = CalculateHeuristic(i - 1, j, dest);
				FNew = GNew + HNew;

				// If node not on list add it
				if (NodeDets[i - 1][j].F == FLT_MAX || NodeDets[i - 1][j].F > FNew)	// Specility of the A Star (The brains of the algo)
				{
					openList.insert(make_pair(FNew, make_pair(i - 1, j)));

					// Update Node
					NodeDets[i - 1][j].F = FNew;
					NodeDets[i - 1][j].G = GNew;
					NodeDets[i - 1][j].H = HNew;
					NodeDets[i - 1][j].ParentI = i;
					NodeDets[i - 1][j].ParentJ = j;
				}
			}
		}

		// Down Neigbour


		if (IsValid(i + 1, j) == true)
		{
			if (IsDestination(i + 1, j, dest) == true)
			{

				NodeDets[i + 1][j].ParentI = i;
				NodeDets[i + 1][j].ParentJ = j;

				cout << "The destination node had been found" << endl;
				PathAStar(NodeDets, dest);
				FoundDest = true;
				return;
			}

			else if (ClosedList[i + 1][j] == false && InUnBlocked(grid, i + 1, j) == true)
			{
				GNew = NodeDets[i][j].G + 1.0;
				HNew = CalculateHeuristic(i + 1, j, dest);
				FNew = GNew + HNew;

				if (NodeDets[i + 1][j].F == FLT_MAX || NodeDets[i + 1][j].F > FNew)
				{
					openList.insert(make_pair(FNew, make_pair(i + 1, j)));

					NodeDets[i + 1][j].F = FNew;
					NodeDets[i + 1][j].G = GNew;
					NodeDets[i + 1][j].H = HNew;
					NodeDets[i + 1][j].ParentI = i;
					NodeDets[i + 1][j].ParentJ = j;
				}
			}
		}

		// Right Neigbour

		if (IsValid(i, j + 1) == true)
		{

			if (IsDestination(i, j + 1, dest) == true)
			{

				NodeDets[i][j + 1].ParentI = i;
				NodeDets[i][j + 1].ParentJ = j;

				cout << "The destination node had been found " << endl;
				PathAStar(NodeDets, dest);
				FoundDest = true;
				return;
			}


			else if (ClosedList[i][j + 1] == false && InUnBlocked(grid, i, j + 1) == true)
			{
				GNew = NodeDets[i][j].G + 1.0;
				HNew = CalculateHeuristic(i, j + 1, dest);
				FNew = GNew + HNew;


				if (NodeDets[i][j + 1].F == FLT_MAX || NodeDets[i][j + 1].F > FNew)
				{
					openList.insert(make_pair(FNew, make_pair(i, j + 1)));

					NodeDets[i][j + 1].F = FNew;
					NodeDets[i][j + 1].G = GNew;
					NodeDets[i][j + 1].H = HNew;
					NodeDets[i][j + 1].ParentI = i;
					NodeDets[i][j + 1].ParentJ = j;
				}
			}
		}

		// Left Neigbour

		if (IsValid(i, j - 1) == true)
		{

			if (IsDestination(i, j - 1, dest) == true)
			{
				NodeDets[i][j - 1].ParentI = i;
				NodeDets[i][j - 1].ParentJ = j;

				cout << "The destination node had been found " << endl;
				PathAStar(NodeDets, dest);
				FoundDest = true;
				return;
			}

			else if (ClosedList[i][j - 1] == false && InUnBlocked(grid, i, j - 1) == true)
			{
				GNew = NodeDets[i][j].G + 1.0;
				HNew = CalculateHeuristic(i, j - 1, dest);
				FNew = GNew + HNew;

				if (NodeDets[i][j - 1].F == FLT_MAX || NodeDets[i][j - 1].F > FNew)
				{
					openList.insert(make_pair(FNew, make_pair(i, j - 1)));

					NodeDets[i][j - 1].F = FNew;
					NodeDets[i][j - 1].G = GNew;
					NodeDets[i][j - 1].H = HNew;
					NodeDets[i][j - 1].ParentI = i;
					NodeDets[i][j - 1].ParentJ = j;
				}
			}
		}

	}
	// Finally if there is no way to reach the destination node then we post the following
	if (FoundDest == false)
	{
		cout << "Failed to the the Destination Node" << endl;

		return;
	}

}
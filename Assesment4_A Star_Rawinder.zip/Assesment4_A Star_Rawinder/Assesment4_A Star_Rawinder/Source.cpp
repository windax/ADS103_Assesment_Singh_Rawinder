#include "A Star.h"

int main()
{

	AStar astar;

	cout << "----------- A * algorithm implementation -------------" << endl << endl;

	cout << "This is the default graph [4] x [5]" << endl;

	int arraydefualt[4][5] = { {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0} };
	int sourcex, sourcey, destinationx, destinationy;

	// Print default array 
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			// One by one print column for given row 
			cout << "[" << arraydefualt[i][j] << "]";

		}
		cout << endl;
	}

	cout << endl;

	cout << "Please select a source node: " << endl;
	cout << "Source Row: "; cin >> sourcex; cout << "Source Column: "; cin >> sourcey;
	cout << endl;

	cout << "Please select a destination node: " << endl;
	cout << "Destination Row: "; cin >> destinationx; cout << "Destination Column: "; cin >> destinationy;
	cout << endl;

	cout << "You will now explictly create the graph by setting the Obstacles" << endl;
	cout << "0: Obstacle" << endl;
	cout << "1: Non Obstacle" << endl;
	cout << endl;

	// Declaration of variables 
	int row, col, i, j;
	int array[4][5];

	// User input for the 2d array 
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			// One by one column for given row 

			cout << "Enter values for [" << i << "][" << j << "] : ";
			cin >> array[i][j];
		}
	}

	cout << endl << endl;

	array[sourcex][sourcey] = 8;
	array[destinationx][destinationy] = 9;

	// Print the 2d array 
	cout << "Here is your graph visualized" << endl;
	cout << "0: Obstacle, 1: Non Obstacle, 8: Source, 9: Destination" << endl;
	cout << endl;

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			// One by one print column for given row 
			cout << "[" << array[i][j] << "]";
		}
		cout << endl;
	}

	array[sourcex][sourcey] = 1;
	array[destinationx][destinationy] = 1;

	typedef pair<int, int> Pair;

	// Source 
	Pair src = make_pair(sourcex, sourcey);

	// Destination 
	Pair dest = make_pair(destinationx, destinationy);

	cout << endl;
	astar.AStarSearch(array, src, dest);
	cout << endl;

	return(0);
}

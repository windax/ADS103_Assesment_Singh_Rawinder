// Include the realitive libaries that are used in the program 
#include <iostream>
#include <memory>		// Allows for dynamic memory mangement 
#include <queue>		// STL Queue 
#include <set>			// Provides container that store unique elements 
#include <stack>		// STL Stack 
#include <utility>		// Pairs used in AStar // Make Pair function 
using namespace std;

#define Row 4			// Definition of Row for our Grid in the search space 
#define Col 5			// Definition of Col for our Grid in the search space 

class AStar
{
public:

	// Node Structure that holds the Parent and Heuristic members params 
	struct Node
	{
		int ParentI, ParentJ;		// Indexes of the parents 
		double F, G, H;				// Heuristics variables 
	};

	typedef pair<int, int> Pair; // Unique Set of int pairs // Used to pair the respective ROW X COL

	typedef pair<double, pair<int, int>> pPair; // Set of double and Pair(int int) // Open List to store elements that have been explored;

	// Member functions of the AStar Class 
	bool IsValid(int row, int col);
	bool InUnBlocked(int grid[][Col], int row, int col);
	bool IsDestination(int row, int col, Pair dest);
	double CalculateHeuristic(int row, int col, Pair dest);
	void PathAStar(Node cellDetails[][Col], Pair dest);
	void AStarSearch(int grid[Row][Col], Pair src, Pair dest);

};
#pragma once
#include <iostream>
#include <vector> 
#include <queue>		// STL que used to not end up reinventing the wheel
#include <stack>		// Same case here
#include <map>			// Make the adjence list
#include <list>			// For the node list

using namespace std;

class GraphTraversal		// Class dec
{

public:

	// Member vars

	// Map class template to hold the values 
	map<int, list<int> > BFSlist;				// BFS List
	map<int, list<int> > DFSlist;				// DFS List

	// Member functions 

	void EdgeBFS(int u, int v);		// This function will give the neibouring nodes ie the connections 
	void EdgeDFS(int u, int v);		// Dito

	void BFS(int source);			// BFS Function that will estentially Traverse the undirected graph			// Takes in the source node as a parameter 
	void DFS(int source);			// DFS Function that will estentially Traverse the undirected graph			// Takes in the source node as a parameter 


};
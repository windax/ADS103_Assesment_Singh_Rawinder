/*In computer science, graph traversal (also known as graph search) 
refers to the process of visiting (checking and/or updating) each 
vertex in a graph. Such traversals are classified by the order 
              in which the vertices are visited. */

#pragma once
#include "GraphTraversal.h"
using namespace std;

int main()
{
	cout << "----------Graph Traversal----------" << endl;

	GraphTraversal g; // Creating a object of type GraphTraversal Class 
	
	// Create the edges (connections between nodes)
	g.EdgeBFS(0, 2);	
	g.EdgeBFS(0, 1);
	g.EdgeBFS(1, 3);
	g.EdgeBFS(2, 0);

	cout << "BFS traversal is " << " ";
	
	g.BFS(0); // Call the Breadth first function that will traverse the graph in a BFS fashion 

	cout << endl;

	// Create the edges 
	g.EdgeDFS(0, 2);	
	g.EdgeDFS(0, 1);
	g.EdgeDFS(1, 3);
	g.EdgeDFS(2, 0);

	cout << "DFS traversal is " << " ";

	g.DFS(0); // Call the Deapth first function that will traverse the grpah in a DFS fashion 

	cout << endl;

	return (0);

}
#include "GraphTraversal.h"

void GraphTraversal::EdgeBFS(int u, int v)
{
	BFSlist[u].push_back(v);	// Push the Vertices
}

void GraphTraversal::EdgeDFS(int u, int v)
{
	DFSlist[u].push_back(v);	// Push the Vertices
}

void GraphTraversal::BFS(int source)
{
	queue<int>q; // Queue using the STL lib
	q.push(source);		// Push the source 

	map<int, int> visitBFS;		// Map array for the visited nodes 

	visitBFS[source] = true;

	while (!q.empty())		// Loop until empty
	{
		int u = q.front();		// This will be the front of queue 
		cout << u << " ";		// Display front to console
		q.pop();				// Pop node from que

		// loop for traverse 
		for (int neighbor : BFSlist[u])
		{
			if (!visitBFS[neighbor])
			{
				q.push(neighbor);
				visitBFS[neighbor] = true;

			}
		}
	}
}

void GraphTraversal::DFS(int source)
{
	stack<int>S; // Stack using the STL lib
	S.push(source);			// Push the source 

	map<int, int> visitDFS;		// Map array for the visited nodes 

	visitDFS[source] = true;

	while (!S.empty())		// Loop until empty
	{
		int u = S.top();				// This will be the front of queue 
		cout << u << " ";				// Display front to console
		S.pop();						// Pop node from que

		// loop for traverse 
		for (int neighbor : DFSlist[u])
		{
			if (!visitDFS[neighbor])
			{
				S.push(neighbor);
				visitDFS[neighbor] = true;

			}
		}
	}
}
